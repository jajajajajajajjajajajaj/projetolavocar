﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Enun
{
   public enum ETipoPessoa
   {
        PessoaFisica = 1,
        PessoaJuridica = 2,
        Conveniado = 3
   }
}
