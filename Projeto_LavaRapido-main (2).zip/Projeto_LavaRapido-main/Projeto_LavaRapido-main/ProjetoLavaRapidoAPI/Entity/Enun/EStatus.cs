﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Enun
{
    public enum EStatus
    {
        Aguardando = 1,
        Lavando = 2,
        Finalizado = 3,
        Entregue = 4
   
    }
}
