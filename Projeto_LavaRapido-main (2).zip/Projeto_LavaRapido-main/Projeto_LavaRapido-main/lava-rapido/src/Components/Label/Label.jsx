import React from 'react'

const Label = ({text}) => {
  return (
    <div>
        <Label>{text}:</Label>
    </div>
  )
}

export default Label